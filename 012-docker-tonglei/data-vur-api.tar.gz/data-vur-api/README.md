# data-marketplace-product-template-api

DPL Product Template API

This is the data product API template containing a sample API based on Python. The API is containerized as part of the build pipeline and the image is pushed to the megatron container image registry. Furthermore the latest commit hash will be used as the image tag and the pipeline updates a helm chart value file in the centralized vwdfive/data-marketplace-argocd repo with that image tag.

If you need help or have any questions, don't hesitate to contact your SPoC (Single Point of Contact) or directly the PO Aliaksei Toustsik.

Link to Confluence: https://devstack.vwgroup.com/confluence/display/DPL/DPL+Team+Overview
Link to Jira: https://devstack.vwgroup.com/jira/secure/RapidBoard.jspa?rapidView=15204&projectKey=DPL&view=planning&issueLimit=100

# data-product

This block provides a template for documenting the data product. To ease the maintenance for the teams responsible for the data product, following information should be additionally supplied.

> Please update the documenation with the specific information about your project.

## General Information

### Name

What is the name of the data product? Does it follow a specific naming pattern?

### Purpose

What is the data product trying to achieve? For example what justifies the need for the data product?

### Data Sources

Where is the data coming from? (Application/Bucket/DB)?

### Data Destination

Consumers can be listed here.

### Responsible Team/Owner

Who is responsible for the data product and its maintenance. (Name, mail, department, ...)

### Stakeholders

Who are the stakeholders and what is their stake? E.g. API Marketplace Team, consumers

## Local Setup

Describe recommended steps to get started with the data product really quick and use them efficiently.

### Techstack

What kind of technologies are in use? It could be frameworks/libraries/tools used for Unit and/or Integration testing or other stuff.

### Prerequisites

Is there anything the consumer requires before using the data product? E.g. installing framework/libs/tool?

### Access rights

Does the consumer need access rights. Where do they obtain them?

### How-to use the data product

Link to documentation (e.g. python/Jupyter notebooks) demonstrating how to make use of the data product.

### Deploy data product

Steps to deploy the data product. E.g. make it available for the API.

## Information Architecture

Any positives and negatives which made the team choose this specific architecture? Aspects or advantage influenced the decisions? What are the main decision drivers? (Cost, Ease of Integration, End-user experience, ...)
Database schema, relationships, ...

### Components

What components belong to the architecture of your data product? What do they do/provide?

### DataFlow

Describe how the process uses the components.

## Miscellaneous

Any additional information.

# Additional tooling

## pre-commit-hooks 
https://pre-commit.com/#install
