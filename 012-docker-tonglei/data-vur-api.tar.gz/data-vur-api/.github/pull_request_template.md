# Pull Request 🚀

## Description 📝
<!-- Please adjust this message to your changes. Remove unnecessary parts. -->

### Change(s) made
<!-- add user into the mega.yml -->
<!-- delete user from mega.yml -->
<!-- implement kevault secret scope in databricks -->
<!-- etc  -->
-

### Related issue(s)/User story(ies)
<!-- fix #413 -->
<!-- https://devstack.vwgroup.com/jira/browse/DPL-531 -->
-

#### Tasks
<!-- You can check the boxes after creating the pull-request -->
- [ ] No hard-coded secrets are utilized 👀
