"""Main api."""
from fastapi import FastAPI

SUMMARY = """
The Product API Template is a robust starting point for building a scalable and efficient API for your product. 🚀
"""
DESCRIPTION = """

### Health Check Endpoints
The Product API Template includes Megatron/Kubernetes-ready endpoints to monitor the health of your API service.
It provides a readiness check endpoint to verify if the API service is ready to handle requests, and a liveness check endpoint to ensure its availability.
By incorporating these endpoints, you can maintain the reliability and availability of your API service in Megatron environment.
"""

app = FastAPI(
    title="Product API Template",
    summary=SUMMARY,
    description=DESCRIPTION,
    version="0.1.0",
    contact={
        "name": "Data Provisioning Layer",
        "email": "aliaksei.toustsik@cariad.technology;kamrul.hassan@cariad.technology;c12e2788.volkswagengroup.onmicrosoft.com@emea.teams.ms",
        "url": "https://devstack.vwgroup.com/confluence/display/DPL/Data+Provisioning+Layer",
    },
    external_docs={
        "description": "GitHub Repository",
        "url": "https://github.com/vwdfive/data-marketplace-product-template-api",
    },
)


@app.get("/", include_in_schema=False)
def root():
    """
    Root endpoint of the API.
    """
    return {"message": "API works"}


@app.get("/helloWorld", tags=["HelloWorld"])
async def hello_world():
    """
    Endpoint to greet the world.
    """
    return {"message": "Hello World"}


@app.get("/health/liveness", tags=["Health"])
async def alive_check():
    """
    Liveness check endpoint.
    """
    return "alive"


@app.get("/health/readiness", tags=["Health"])
async def health_check():
    """
    Readiness check endpoint.
    """
    return "ready"
